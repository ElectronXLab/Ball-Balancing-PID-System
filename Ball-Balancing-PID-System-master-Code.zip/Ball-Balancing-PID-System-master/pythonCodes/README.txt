data.txt and interface.py have to be in the same folder.
