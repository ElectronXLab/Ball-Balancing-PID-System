# Ball-Balancing-PID-System

To support the project : https://www.fantasticobject.com/products/babot 

![image](images/DSC_4337.JPG)


license : https://creativecommons.org/licenses/by-nc-sa/4.0/

